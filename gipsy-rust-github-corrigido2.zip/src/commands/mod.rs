pub mod registry;
pub mod handler;

pub async fn dispatch(command: &str) -> anyhow::Result<()> {
    handler::dispatch(command).await
}
