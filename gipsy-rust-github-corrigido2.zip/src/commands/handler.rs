pub async fn dispatch(command: &str) -> anyhow::Result<()> {
    match command {
        // First migration slice will implement these against whatsapp-rust.
        // Keeping every command registered prevents accidental feature loss
        // while the implementation is being ported module by module.
        _ if crate::commands::registry::VALID_COMMANDS.contains(&command) => {
            tracing::info!(command, "Comando reconhecido; handler ainda em migração");
            Ok(())
        }
        _ => Ok(()),
    }
}
