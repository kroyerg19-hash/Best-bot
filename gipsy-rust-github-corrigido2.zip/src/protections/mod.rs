pub async fn init() -> anyhow::Result<()> {
    // Protection pipeline to be implemented:
    // anti-link, anti-flood, anti-payment, anti-fantasma, anti-bot,
    // anti-fake, anti-sticker/audio/video/document/photo/mention/contact,
    // anti-location, anti-word and anti-roubo.
    Ok(())
}
