pub async fn init() -> anyhow::Result<()> {
    // The JS version currently persists many JSON maps. The Rust target will
    // consolidate them into SQLite while preserving their logical keys.
    tokio::fs::create_dir_all("./data").await?;
    Ok(())
}
